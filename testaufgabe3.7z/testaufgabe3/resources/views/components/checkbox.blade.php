<div class="checkbox col-lg-12">
    <label>
        {!! Form::checkbox($name) !!}
        {{ $label }}
    </label>
</div>