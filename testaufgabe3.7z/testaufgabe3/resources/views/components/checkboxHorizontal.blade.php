<div class="form-group">
    <div class="checkbox">
        <label>
            {!! Form::checkbox($name, $value) !!}
            {{ $label }}
        </label>
    </div>
</div>