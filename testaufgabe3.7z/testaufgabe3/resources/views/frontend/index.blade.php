@extends('frontend.layouts.app')
@section('page_heading','Dashboard')
@section('content')
    <div class="row">

   

     
    
        <div class="col-xs-12">

            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-home"></i> Testaufgabe </div>

                <div class="panel-body">
                  Dies ist ein Arbeit von verschieden alte code gesammlt, und einem Framework eingefügt. </br> </br>  </br> 

                  Den Administrator Account lautet :  email :    password :     </br> </br> 
                  Den Backend Account lautet :  email :    password :    </br>  </br>  
                  Den User Account lautet :   email :    password :    </br> </br>  </br> </br> 

                  Unter diesem Link  finden Sie meine fertige Autowerbung Website, der mit Laravel 5.4 geschrieben ist und enthält mehr SQL Funktionen. </br> </br>


                  Unter Diesem Link finden Sie eine Anruf von Aimeos  e-commerce package and online shop solution unter Laravel. </br> </br>


                  Außerdem habe ich mit den Framework Three.js beginnen, um ein  Konfigurator mit Javascript zu programmieren


                </div>
















            </div><!-- panel -->

        </div><!-- col-md-10 -->

    </div><!--row-->
@endsection