@extends('front.template')

@section('main')


  <div class="get-started center wow fadeInDown">
                <h2>Update </h2>
              
                <div class="request">
                    <h4><a href="#">Request a free Quote</a></h4>
                </div>
            </div><!--/.get-started-->
			
<section id="blog" class="container">


<center>


    {!! Form::model($car, ['route' => ['car.update', $car->id], 'method' => 'put', 'class' => 'form-horizontal panel']) !!}

	
	
	 {!! Form::controlBootstrap('text', 12, 'title', $errors, trans('back/blog.summary')) !!}
	
	 {!! Form::controlBootstrap('textarea', 12, 'content', $errors, trans('back/blog.content')) !!}

	
            {!! Form::submitBootstrap(trans('front/form.send')) !!}

        {!! Form::close() !!}
	
	
	
	</center>
	</section>
	
	
	
	
	
	
	@endsection
