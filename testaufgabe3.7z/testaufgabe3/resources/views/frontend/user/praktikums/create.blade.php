@extends('front.template')




@section('main')



  <div class="get-started center wow fadeInDown">
                <h2>New Car </h2>
              
                <div class="request">
                    <h4><a href="#">Request a free Quote</a></h4>
                </div>
            </div><!--/.get-started-->
			
<section id="blog" class="container">


<center>

<div class="progress">
    <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
  </div>
  @if(session('statut') != 'visitor')
  <form id="regiration_form" novalidate method="POST" action="/car" enctype="multipart/form-data">
  
  

  
  {{ csrf_field() }}
  
  
  
  <fieldset>
    <h2>Step 1: Beschreibung</h2>
    <div class="form-group">
    <label for="title">Title</label>
    <input type="text" class="form-control" id="title" name="title" placeholder="Title">
    </div>
    <div class="form-group">
     {!! Form::controlBootstrap('textarea', 12, 'content', $errors, trans('front/contact.details')) !!} 
    </div>
	
	
	
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
    <input type="button" name="content" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
  

  
    
  <fieldset>
    <h2>Step 2: Angaben zum Fahrzeug</h2>
	
	
	
     <div class="form-group">
                            <label class="col-md-4 control-label">Marke</label>
                            <div class="col-md-6">
                                <select class="form-control" name="marke">
                                    @foreach ($markes as $marke)
                                        <option value="{{$marke->id}}">{{$marke->marke_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
	</br>
	</br>
	</br>
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Type</label>
                            <div class="col-md-6">
                                <select class="form-control" name="model">
                                    @foreach ($modells as $modell)
                                        <option value="{{$modell->id}}">{{$modell->model_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
		</br>
	</br>
	</br>
		
    <div class="form-group">
   <label class="col-md-4 control-label">Baujahr</label>
     <div class="col-md-6">
   <select class="form-control" name="baujahr">
                                    @foreach ($baujahrs as $baujahr)
                                        <option value="{{$baujahr->id}}">{{$baujahr->baujahr}}</option>
                                    @endforeach
                                </select>   </div>
    </div>
  
	
	
	
		</br>
	</br>
	</br>
	
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Karosserieform</label>
                            <div class="col-md-6">
                                <select class="form-control" name="carosserie">
                                    @foreach ($carosseries as $carosserie)
                                        <option value="{{$carosserie->id}}">{{$carosserie->form_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
	
		</br>
	</br>
	</br>
	
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Farbe</label>
                            <div class="col-md-6">
                                <select class="form-control" name="color">
                                    @foreach ($colors as $color)
                                        <option value="{{$color->id}}">{{$color->color_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
	
	</br>
	
	
	</br>
		
    <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
  
  
  <fieldset>
  
  
  
  
    <h2> Step 3: Angaben zum Fahrverhalten</h2>
   	
     <div class="form-group">
                            <label class="col-md-4 control-label">Welche Wege nehmen Sie am Meistens </br> Place 1 : (Optional)</label>
					
							
                            <div class="col-md-3">
							
							  <h4> From </h4>
							  
                                <select class="form-control" name="place">
								  
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							<div class="col-md-3">
							 <h4> To </h4>
                                <select class="form-control" name="place2">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							
						</br>
	                     </br>
							 <label class="col-md-4 control-label">Place 2 : (Optional)</label>
							
							
                            <div class="col-md-3">
							<h4> From </h4>
                                <select class="form-control" name="place3">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							<div class="col-md-3">
							 <h4> To </h4>
                                <select class="form-control" name="place4">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}">{{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							</br>
	</br>
							
							 <label class="col-md-4 control-label"> Place 3 : (Optional) </label>
							
							
                            <div class="col-md-3">
							<h4> From </h4>
                                <select class="form-control" name="place5">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							<div class="col-md-3">
							 <h4> To </h4>
                                <select class="form-control" name="place6">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							
							</br>
								</br>
									</br>

                        </div>
  
	  </br></br>
	
	
	</br>
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Stehen oder Fahren ?</label>
                            <div class="col-md-6">
                                <select class="form-control" name="zustand">
                                    @foreach ($zustands as $zustand)
                                        <option value="{{$zustand->id}}">{{$zustand->zustand_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
 
		</br>
	</br>
	</br>
     <div class="form-group">
                            <label class="col-md-4 control-label">Arbeit oder zu Hause ?</label>
                            <div class="col-md-6">
                                <select class="form-control" name="situation">
                                    @foreach ($situations as $situation)
                                        <option value="{{$situation->id}}">{{$situation->situation}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
  
  
  
  
  
  
 
  
  
  	
     
</br></br>
	</br></br>
	
    <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
   <fieldset>
  
      <h2> Step 4: Angaben zum Werbflächen</h2>
  
  
  	
     <div class="form-group">
                            <label class="col-md-4 control-label">Werbungstyp</label>
                            <div class="col-md-6">
                                <select class="form-control" name="werbung">
                                    @foreach ($werbungs as $werbung)
                                        <option value="{{$werbung->id}}">{{$werbung->werbung_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
			

	
	</br>
	</br>
	</br>
	</br>
	</br></br></br></br></br>
	</br>
	</br>
	</br></br></br>
	
	</br></br>
	
	</br>
	</br>

	
	
			
    <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
  
   
  
     <fieldset>
  
          <h2>Step 5: Pictures</h2>
                       <div class="form-group">
                    <label class=""> picture1 </label>
                    <input name="images1" type="file" class="btn btn-default" />
					
  
		</br>

	
					
                <label class=""> picture2 </label>
                    <input name="images2" type="file" class="btn btn-default" />
					
					
  
		</br>

	
					 <label class=""> picture3 </label>
                    <input name="images3" type="file" class="btn btn-default" />
					
					
					
  
		</br>

	
					 <label class=""> picture4 </label>
                    <input name="images4" type="file" class="btn btn-default" />
					
					
					
  
		</br>

	
					 <label class=""> picture5 </label>
                    <input name="images5" type="file" class="btn btn-default" />

  
                </div>

	 <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
   
    <input type="submit" name="submit" class="submit btn btn-danger" value="Submit" />
  
  </fieldset>
  
  </form>
  
  @endif
  
  
  
  
  

  
   
   @if(session('statut') == 'visitor')

    <form id="regiration_form" novalidate method="POST" action="/newcar" enctype="multipart/form-data">
	
	 {{ csrf_field() }}
   <fieldset>
    <h2>Step 1: Beschreibung</h2>
    <div class="form-group">
    <label for="title">Title</label>
    <input type="text" class="form-control" id="title" name="title" placeholder="Title">
    </div>
    <div class="form-group">
     {!! Form::controlBootstrap('textarea', 12, 'content', $errors, trans('front/contact.details')) !!} 
    </div>
	
	
	
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
    <input type="button" name="content" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
  

  
    
  <fieldset>
    <h2>Step 2: Angaben zum Fahrzeug</h2>
	
	
	
     <div class="form-group">
                            <label class="col-md-4 control-label">Marke</label>
                            <div class="col-md-6">
                                <select class="form-control" name="marke">
                                    @foreach ($markes as $marke)
                                        <option value="{{$marke->id}}">{{$marke->marke_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
	</br>
	</br>
	</br>
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Type</label>
                            <div class="col-md-6">
                                <select class="form-control" name="model">
                                    @foreach ($modells as $modell)
                                        <option value="{{$modell->id}}">{{$modell->model_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
		</br>
	</br>
	</br>
		
    <div class="form-group">
   <label class="col-md-4 control-label">Baujahr</label>
     <div class="col-md-6">
   <select class="form-control" name="baujahr">
                                    @foreach ($baujahrs as $baujahr)
                                        <option value="{{$baujahr->id}}">{{$baujahr->baujahr}}</option>
                                    @endforeach
                                </select>   </div>
    </div>
  
	
	
	
		</br>
	</br>
	</br>
	
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Karosserieform</label>
                            <div class="col-md-6">
                                <select class="form-control" name="carosserie">
                                    @foreach ($carosseries as $carosserie)
                                        <option value="{{$carosserie->id}}">{{$carosserie->form_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
	
		</br>
	</br>
	</br>
	
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Farbe</label>
                            <div class="col-md-6">
                                <select class="form-control" name="color">
                                    @foreach ($colors as $color)
                                        <option value="{{$color->id}}">{{$color->color_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
	
	
	</br>
	
	
	</br>
		
    <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
  
  

  <fieldset>
  
  
  
  
    <h2> Step 3: Angaben zum Fahrverhalten</h2>
   	
     <div class="form-group">
                            <label class="col-md-4 control-label">Welche Wege nehmen Sie am Meistens </br> Place 1 : (Optional)</label>
					
							
                            <div class="col-md-3">
							
							  <h4> From </h4>
							  
                                <select class="form-control" name="place">
								  
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							<div class="col-md-3">
							 <h4> To </h4>
                                <select class="form-control" name="place2">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							
						</br>
	                     </br>
							 <label class="col-md-4 control-label">Place 2 : (Optional)</label>
							
							
                            <div class="col-md-3">
							<h4> From </h4>
                                <select class="form-control" name="place3">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							<div class="col-md-3">
							 <h4> To </h4>
                                <select class="form-control" name="place4">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}">{{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							</br>
	</br>
							
							 <label class="col-md-4 control-label"> Place 3 : (Optional) </label>
							
							
                            <div class="col-md-3">
							<h4> From </h4>
                                <select class="form-control" name="place5">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							<div class="col-md-3">
							 <h4> To </h4>
                                <select class="form-control" name="place6">
                                    @foreach ($places as $place)
                                        <option value="{{$place->id}}"> {{$place->places_name}}</option>
                                    @endforeach
                                </select>
                            </div>
							
							</br>
								</br>
									</br>

                        </div>
  
	  </br></br>
	
	
	</br>
		
     <div class="form-group">
                            <label class="col-md-4 control-label">Stehen oder Fahren ?</label>
                            <div class="col-md-6">
                                <select class="form-control" name="zustand">
                                    @foreach ($zustands as $zustand)
                                        <option value="{{$zustand->id}}">{{$zustand->zustand_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
 
		</br>
	</br>
	</br>
     <div class="form-group">
                            <label class="col-md-4 control-label">Arbeit oder zu Hause ?</label>
                            <div class="col-md-6">
                                <select class="form-control" name="situation">
                                    @foreach ($situations as $situation)
                                        <option value="{{$situation->id}}">{{$situation->situation}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
  
  
  
  
  
  
 
  
  
  	
     
</br></br>
	</br></br>
	
    <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  </fieldset>
  
  
   <fieldset>
  
  
   <fieldset>
  
      <h2> Step 4: Angaben zum Werbflächen</h2>
  
  
  	
     <div class="form-group">
                            <label class="col-md-4 control-label">Werbungstyp</label>
                            <div class="col-md-6">
                                <select class="form-control" name="werbung">
                                    @foreach ($werbungs as $werbung)
                                        <option value="{{$werbung->id}}">{{$werbung->werbung_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
  
	
			

	
	</br>
	</br>
	</br>
	</br>
	</br></br></br></br></br>
	</br>
	</br>
	</br></br></br>
	
	</br></br>
	
	</br>
	</br>

	
	
			
    <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  </fieldset>
  
   <fieldset>
  
          <h2>Step 5: Pictures</h2>
                       <div class="form-group">
                    <label class=""> picture1 </label>
                    <input name="images1" type="file" class="btn btn-default" />
					
  
		</br>

	
					
                <label class=""> picture2 </label>
                    <input name="images2" type="file" class="btn btn-default" />
					
					
  
		</br>

	
					 <label class=""> picture3 </label>
                    <input name="images3" type="file" class="btn btn-default" />
					
					
					
  
		</br>

	
					 <label class=""> picture4 </label>
                    <input name="images4" type="file" class="btn btn-default" />
					
					
					
  
		</br>

	
					 <label class=""> picture5 </label>
                    <input name="images5" type="file" class="btn btn-default" />

  
                </div>
	
	 <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
   
    <input type="button" name="next" class="next btn btn-danger" value="Next" />
  
  </fieldset>
  
  
  
   
   <fieldset>
  
          <h2>Step 6: Personal Information</h2>
               <div class="form-group">
  <label class="col-md-4 control-label">Username</label>
                            <div class="col-md-6">
    <input type="text" class="form-control" id="username" name="username" placeholder="Title">
    </div>
	</div>
	</br>
	</br>
	</br>
	</br>
  <label class="col-md-4 control-label">Email</label>
                            <div class="col-md-6">
  
    <input type="email" class="form-control" id="email" name="email" placeholder="email">
    </div>
	</div>

	</br>
	</br>
	</br>
	</br>
	<label class="col-md-4 control-label">Handy</label>
                            <div class="col-md-6">
  
    <input type="tel" class="form-control" id="tel" name="tel" placeholder="Telephone">
    </div>
	</div>
	
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	<label class="col-md-4 control-label"></label>
	   <div class="col-md-6">
	 <input type="button" name="previous" class="previous btn btn-default" value="Previous" />
   
 
    <input type="submit" name="submit" class="submit btn btn-danger" value="Submit" />
  </div>
  </fieldset>
  
  
   </form>
  @endif
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

 

</center>




</section>















@endsection

