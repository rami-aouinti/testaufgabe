@extends('front.template')

@section('head')

    <meta name="csrf-token" content="{{ csrf_token() }}">
    {!! HTML::style('ckeditor/plugins/codesnippet/lib/highlight/styles/monokai.css') !!}

@stop

@section('main')






      <section id="blog" class="container">
      
             <div class="get-started center wow fadeInDown">
                <h2>{!! $car->title !!} </h2>
                <p class="lead">{!!$car->content!!}</p>
                <div class="request">
                    <h4><a href="#">Details</a></h4>
                </div>
            </div><!--/.get-started-->
       

        <div class="blog">
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-item">
                        <img class="img-responsive img-blog" src="../app/{!! $car->images1 !!}" width="75%" alt="" />
                            <div class="row">  
							
							
							
							
							
							
							
							
							  <div class="col-xs-12 col-sm-4 text-center">
                                <div class="entry-meta">
								
								
				
								
								
                                    <span id="publish_date">{!! strstr($car->created_at, ' ', true) !!}</span>
									
										@foreach ($markes as $marke)
									 @if($marke->id==$car->marke_id)
										 
									 
                                    <span><i class="fa fa"></i> <a href="#"> Marke      :  {!! $marke->marke_name !!}</a></span>
									@endif
									
									@endforeach
									@foreach ($modells as $modell)
									 @if($modell->id==$car->model_id)
									
                                    <span><i class="fa fa"></i> <a href="#"> Type       :  {!! $modell->model_name !!}</a></span>
									
									@endif
									
									@endforeach
									
									
									@foreach ($carosseries as $modell)
									 @if($modell->id==$car->carosserie_id)
									 <span><i class="fa fa"></i> <a href="#">Carosserie :  {!! $modell->form_name !!} </a></span>
									 
									 
									 @endif
									
									@endforeach
									 
									 @foreach ($baujahrs as $modell)
									 @if($modell->id==$car->baujahr_id)
                                    <span><i class="fa fa"></i> <a href="#"> Baujahr    :  {!! $modell->baujahr !!}</a></span>
									
									@endif
									
									@endforeach
									
									@foreach ($colors as $modell)
									 @if($modell->id==$car->color_id)
									 <span><i class="fa fa"></i> <a href="#">Color      :  {!! $modell->color_name !!}</a></span>
									 
									@endif
									
									@endforeach

                                   @foreach ($werbungs as $modell)
									 @if($modell->id==$car->werbung_id)									
                                    <span><i class="fa fa"></i> <a href="#"> Werbung    :  {!! $modell->werbung_name !!}</a></span>
									
									@endif
									
									@endforeach
									
									@foreach ($places as $modell)
									 @if($modell->id==$car->place_id)
									 <span><i class="fa fa"></i> <a href="#">Bezirke    :  {!! $modell->places_name !!}</a></span>
									 
									 @endif
									
									@endforeach
									 
									 @foreach ($zustands as $modell)
									 @if($modell->id==$car->zustand_id)
									 
                                    <span><i class="fa fa"></i> <a href="#"> Zustand    :  {!! $modell->zustand_name !!}</a></span>
								@endif
									
									@endforeach
                             
                                </div>
                            </div>
							
							
							
							
							
							
							
					
							
                      
								
								
                               
                                <div class="col-xs-12 col-sm-6 blog-content">
                               
									 
									 
                                    <div class="post-tags">
                       
						
				 <ul class="sidebar-gallery">
                            <li><a href="#"><img src="../app/{!! $car->images2 !!}" alt="" width="150px" /></a></li>
                            <li><a href="#"><img src="../app/{!! $car->images3 !!}" alt="" width="150px" /></a></li>
                            <li><a href="#"><img src="../app/{!! $car->images4 !!}" alt="" width="150px" /></a></li>
                            <li><a href="#"><img src="../app/{!! $car->images5 !!}" alt="" width="150px" /></a></li>
                        </ul>
						
						
						
						
						
		
					




							
							
			






	
					   

						</div>

                                </div>
                            </div>
                        </div><!--/.blog-item-->
                        
                    
                    
                   
                     


                        <div id="contact-page clearfix">
                            <div class="status alert alert-success" style="display: none"></div>
                            <div class="message_heading">
							
							 @if(session('statut') == 'company')
                                <h4>Create message</h4>
							
							@endif
                                 </div> 
      
	  
	  
	  
	  
	                    @if(session()->has('warning'))
                            @include('partials/error', ['type' => 'warning', 'message' => session('warning')])
                        @endif  
                        @if(session('statut') == 'company')
                    {!! Form::open(['url' => 'message']) !!}  
    
                    <div class="row">
					   {!! Form::hidden('user_id', Auth::user()->id) !!}
					    {!! Form::hidden('car_id', $car->id) !!}
					
						
					
					
					
					
					
					{!! Form::hidden('to','1') !!}
					
				
					
					
					
					
					
					
					
					
						   {!! Form::hidden('tel', Auth::user()->tel) !!}
						
			            {!! Form::controlBootstrap('text', 6, 'name', $errors, trans('back/blog.companyname')) !!}
						{!! Form::controlBootstrap('text', 6, 'from', $errors, trans('back/blog.email')) !!}
						{!! Form::controlBootstrap('text', 6, 'tel', $errors, trans('back/blog.tel')) !!}
						{!! Form::controlBootstrap('text', 6, 'title', $errors, trans('back/blog.subject')) !!}
                        {!! Form::controlBootstrap('textarea', 12, 'message', $errors, trans('front/contact.message')) !!}     
                        {!! Form::submitBootstrap(trans('front/form.send'), 'col-lg-12') !!}
                    </div>
                {!! Form::close() !!}
                        
                          
                        @endif
	  
	  
	  
	  




	   
                        </div><!--/#contact-page-->
                    </div><!--/.col-md-8-->

					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
                <aside class="col-md-4">
                    <div class="widget search">
                        <form role="form">
                                <input type="text" class="form-control search_box" autocomplete="off" placeholder="Search Here">
                        </form>
                    </div><!--/.search-->
    				
    	  <div class="widget categories">
                        <h3>Places</h3>
                        <div class="row">
                            <div class="col-sm-6">
                                <ul class="blog_category">
                                    <li><a href="#">Wedding <span class="badge">04</span></a></li>
                                    <li><a href="#">Neuköln <span class="badge">10</span></a></li>
                                    <li><a href="#">Marzahn <span class="badge">06</span></a></li>
                                    <li><a href="#">Spandau <span class="badge">25</span></a></li>
                                </ul>
                            </div>
                        </div>                     
                    </div><!--/.categories-->
    				
    				<div class="widget archieve">
                        <h3>Marke</h3>
                        <div class="row">
                            <div class="col-sm-12">
                                <ul class="blog_archieve">
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Bmw <span class="pull-right">(97)</span></a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Audi <span class="pull-right">(32)</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Volkswagen <span class="pull-right">(19)</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Renault <span class="pull-right">(08)</a></li>
                                </ul>
                            </div>
                        </div>                     
                    </div><!--/.archieve-->
    				
                 
    				
    				<div class="widget blog_gallery">
                        <h3>Our Gallery</h3>
                        <ul class="sidebar-gallery">
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/1.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/2.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/3.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/4.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/5.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/6.jpg") }}" alt="" width="100px" /></a></li>
                        </ul>
                    </div><!--/.blog_gallery-->
    				
                </aside>     

            </div><!--/.row-->

         </div><!--/.blog-->

    </section><!--/#blog-->

@stop

@section('scripts')

    {!! HTML::script('ckeditor/plugins/codesnippet/lib/highlight/highlight.pack.js') !!}

    @if(session('statut') != 'visitor')
        {!! HTML::script('ckeditor/ckeditor.js') !!}
        {!! HTML::script('js/sweetalert.min.js') !!}
    @endif

    <script>      

        @if(session('statut') != 'visitor')
            
            $(function() {

                function ckeditorReplace(element) {
                    CKEDITOR.replace(element, {
                        language: '{{ config('app.locale') }}',
                        height: 200,
                        toolbarGroups: [
                            { name: 'basicstyles', groups: [ 'basicstyles'] }, 
                            { name: 'links' },
                            { name: 'insert' }
                        ],
                        removeButtons: 'Table,SpecialChar,HorizontalRule,Anchor'
                    });                
                }

                ckeditorReplace('comments');

                function buttons(i) {
                    return "<input id='val" + i +"' class='btn btn-default' type='submit' value='{{ trans('front/blog.valid') }}'><input id='btn" + i + "' class='btn btn-default btnannuler' type='button' value='{{ trans('front/blog.undo') }}'></div>";
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $('a.editcomment span').tooltip();
                $('a.deletecomment span').tooltip();

                // Set comment edition
                $('a.editcomment').click(function(e) {   
                    e.preventDefault();
                    $(this).hide();
                    var i = $(this).attr('id').substring(7);
                    var existing = $('#content' + i).html();
                    var url = $('#formcreate').find('form').attr('action');
                    jQuery.data(document.body, 'comment' + i, existing);
                    var html = "<div class='row'><form id='form" + i + "' method='POST' action='" + url + '/' + i + "' accept-charset='UTF-8' class='formajax'><div class='form-group col-lg-12 '><label for='comments' class='control-label'>{{ trans('front/blog.change') }}</label><textarea id='cont" + i +"' class='form-control' name='comments" + i + "' cols='50' rows='10' id='comments" + i + "'>" + existing + "</textarea><small class='help-block'></small></div><div class='form-group col-lg-12'>" + buttons(i) + "</div>";
                    $('#content' + i).html(html);
                    ckeditorReplace('comments' + i);
                });

                // Escape edition
                $(document).on('click', '.btnannuler', function() {    
                    var i = $(this).attr('id').substring(3);
                    $('#comment' + i).show();
                    $('#content' + i).html(jQuery.data(document.body, 'comment' + i));
                });

                // Validation comment
                $(document).on('submit', '.formajax', function(e) {  
                    e.preventDefault();
                    var i = $(this).attr('id').substring(4);
                    $('#val' + i).parent().html('<i class="fa fa-refresh fa-spin fa-2x"></i>').addClass('text-center');
                    $.ajax({
                        method: 'put',
                        url: $(this).attr('action'),
                        data: $(this).serialize()
                    })
                    .done(function(data) {
                        $('#comment' + data.id).show();
                        $('#content' + data.id).html(data.content); 
                    })
                    .fail(function(data) {
                        var errors = data.responseJSON;
                        $.each(errors, function(index, value) {
                            $('textarea[name="' + index + '"]' + ' ~ small').text(value);
                            $('textarea[name="' + index + '"]').parent().addClass('has-error');
                            $('.fa-spin').parent().html(buttons(index.slice(-1))).removeClass('text-center');
                        });
                    });
                });

                // Delete comment
                $('a.deletecomment').click(function(e) {   
                    e.preventDefault(); 
                    var that = $(this);
                    swal({
                        title: "{!! trans('front/blog.confirm') !!}",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "{!! trans('front/site.yes') !!}",
                        cancelButtonText: "{!! trans('front/site.no') !!}"
                    }, function(isConfirm) {
                        if (isConfirm) {
                            var i = that.attr('id').substring(13);
                            that.replaceWith('<i class="fa fa-refresh fa-spin pull-right"></i>');
                            $.ajax({
                                method: 'delete',
                                url: '{!! url('comment') !!}' + '/' + i
                            })
                            .done(function(data) {
                                $('#comment' + data.id).parents('.commentitem').remove();
                            })
                            .fail(function() {
                                alert('{!! trans('front/blog.fail-delete') !!}');
                            }); 
                        }                
                    });
                });

            });

        @endif

        hljs.initHighlightingOnLoad();

    </script>

@stop
