@extends('front.template')

@section('main')


  <div class="get-started center wow fadeInDown">
                <h2>My Cars </h2>
              
                <div class="request">
                    <h4><a href="#">Request a free Quote</a></h4>
                </div>
            </div><!--/.get-started-->
			






<section id="blog" class="container">
      
            <h2>Cars</h2>
            <p class="lead">List of cars</p>
      

        <div class="blog">
            <div class="row">
                 <div class="col-md-8">
				 
				 
			
				 
				         @foreach($cars as $car)
				 
				 @if( Auth::user()->id == $car->user_id )
				
				 
				 
                    <div class="blog-item">
                        <div class="row">
                            <div class="col-xs-12 col-sm-4 text-center">
                                <div class="entry-meta">
                                    <span id="publish_date">{!! strstr($car->created_at, ' ', true) !!}</span>
									
							@foreach ($markes as $marke)
									 @if($marke->id==$car->marke_id)
				
                                    <span><i class="fa fa-user"></i> <a href="#"> {!! $marke->marke_name !!}</a></span>
									@endif
									
									@endforeach
									@foreach ($modells as $modell)
									 @if($modell->id==$car->model_id)
                                    <span><i class="fa fa-comment"></i> <a href="blog-item.html#comments">{!! $modell->model_name !!}</</a></span>
                                    @endif
									@endforeach
                                </div>
								 </br>
	   </br>
	   </br>
								 <aside class="col-md-12">
                               
                               {!! link_to_route('car.edit', trans('back/blog.edit'), [$car->id], ['class' => 'btn btn-warning btn-block']) !!}</td>
       </aside>
	   
	   </br>
	   </br>
	   </br>
	      <aside class="col-md-12">
            {!! Form::open(['method' => 'DELETE', 'route' => ['car.destroy', $car->id]]) !!}
                {!! Form::destroyBootstrap(trans('back/blog.destroy'), trans('back/blog.destroy-warning')) !!}
            {!! Form::close() !!}
       </aside>
								
								
								
								
                            </div>
                                
                            <div class="col-xs-12 col-sm-8 blog-content">  
							   <h2>{{ $car->title }}</h2>  
                                <a href="#"><img class="img-responsive img-blog" src="app/{{ $car->images1 }}" width="200px" height="200px" alt="" /></a>
                                                      
						
							
                               
                            
							</div>
                        </div>    
                    </div><!--/.blog-item-->
					
					
					      @endif

					 @endforeach
					
                        
                    
                        
                    <ul class="pagination pagination-lg">
                         {!! $cars->links() !!}
                    </ul><!--/.pagination-->
					
					
					
					
					
					
                </div><!--/.col-md-8-->

                <aside class="col-md-4">
                    <div class="widget search">
                        {!! Form::open(['url' => 'car/search', 'method' => 'get', 'role' => 'form', 'class' => 'pull-right']) !!}  
                {!! Form::controlBootstrap('text', 12, 'search', $errors, null, null, null, trans('front/blog.search')) !!}
                  {!! Form::close() !!}
                    </div><!--/.search-->
    				
    
                     

                    <div class="widget categories">
                        <h3>Places</h3>
                        <div class="row">
                            <div class="col-sm-6">
                                <ul class="blog_category">
                                    <li><a href="#">Wedding <span class="badge">04</span></a></li>
                                    <li><a href="#">Neuköln <span class="badge">10</span></a></li>
                                    <li><a href="#">Marzahn <span class="badge">06</span></a></li>
                                    <li><a href="#">Spandau <span class="badge">25</span></a></li>
                                </ul>
                            </div>
                        </div>                     
                    </div><!--/.categories-->
    				
    				<div class="widget archieve">
                        <h3>Marke</h3>
                        <div class="row">
                            <div class="col-sm-12">
                                <ul class="blog_archieve">
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Bmw <span class="pull-right">(97)</span></a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Audi <span class="pull-right">(32)</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Volkswagen <span class="pull-right">(19)</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Renault <span class="pull-right">(08)</a></li>
                                </ul>
                            </div>
                        </div>                     
                    </div><!--/.archieve-->
    				
                 
    				
    				<div class="widget blog_gallery">
                        <h3>Our Gallery</h3>
                        <ul class="sidebar-gallery">
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/1.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/2.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/3.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/4.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/5.jpg") }}" alt="" width="100px" /></a></li>
                            <li><a href="#"><img src="{{ asset("autotemplate/images/blog/6.jpg") }}" alt="" width="100px" /></a></li>
                        </ul>
                    </div><!--/.blog_gallery-->
    			</aside>  
            </div><!--/.row-->
        </div>
    </section><!--/#blog-->

@endsection

