@extends('frontend.layouts.app')

@section('template_title')
  Showing Studiums
@endsection

@section('template_linked_css')
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
    <style type="text/css" media="screen">
        .users-table {
            border: 0;
        }
        .users-table tr td:first-child {
            padding-left: 15px;
        }
        .users-table tr td:last-child {
            padding-right: 15px;
        }
        .users-table.table-responsive,
        .users-table.table-responsive table {
            margin-bottom: 0;
        }

    </style>
@endsection

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">

                       

                        <a href="{{ URL::to('studium/create') }}" class="btn btn-default btn-xs pull-right">
                            <i class="fa fa-fw fa-plus" aria-hidden="true"></i>
                            {{ trans('studiums.btnAddTheme') }}
                        </a>

                    </div>
                    <div class="panel-body">
                        <div class="table-responsive users-table">
                            <table class="table table-striped table-condensed data-table">
                                <thead>
                                    <tr>
                                        {{-- <th>ID</th> --}}
                                        <th>Institut</th>
                                        <th>Domain</th>
                                        <th>Degree</th>
                                        <th> Start</th>
                                        <th> End</th>
                                        <th>{{ trans('studiums.themesActions') }}</th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($studiums as $studium)

                                        @if( $studium->user_id == Auth::User()->id)
                                        
                                        <tr>
                                            {{-- <td>{{$studium->id}}</td> --}}
                                            <td>
                                              {{$studium->institut}}
                                            </td>
                                            <td>
                                              {{$studium->domain->domain}}
                                            </td>
                                            <td>{{$studium->degree}}</td>
                                            <td>{{$studium->start}}</td>
                                            <td>{{$studium->end}}</td>
                                           
                                            <td>
                                                <a class="btn btn-sm btn-success btn-block" href="{{ URL::to('studium/' . $studium->id) }}" data-toggle="tooltip" title="{{ trans('studium.themesBtnShow') }}">
                                                    <i class="fa fa-eye fa-fw" aria-hidden="true"></i>
                                                    <span class="sr-only">{{ trans('studium.themesBtnShow') }}</span>
                                                </a>
                                            </td>
                                            <td>
                                                
                                                 
                                                 {!! link_to_route('frontend.user.studium.edit', trans('studiums.showUpdated'), [$studium->id], ['class' => 'btn btn-sm btn-warning btn-block']) !!}
                                         </td>
                                            <td>
                                                  {!! Form::open(['method' => 'DELETE', 'route' => ['frontend.user.studium.destroy', $studium->id]]) !!}
                                                    {!! Form::hidden('_method', 'DELETE') !!}
                                                    {!! Form::button('<i class="fa fa-trash-o fa-fw" aria-hidden="true"></i> <span class="sr-only">Delete Studium</span>', array('class' => 'btn btn-danger btn-sm','type' => 'button', 'style' =>'width: 100%;' ,'data-toggle' => 'modal', 'data-target' => '#confirmDelete', 'data-title' => trans('themes.confirmDeleteHdr'), 'data-message' => trans('studium.confirmDelete'))) !!}
                                                {!! Form::close() !!}
                                            </td>
                                        </tr>

                                    @endif

                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('modals.modal-delete')

@endsection

@section('footer_scripts')

    @if (count($studiums) > 50)
        @include('scripts.datatables')
    @endif
    @include('scripts.delete-modal-script')
    @include('scripts.save-modal-script')
    @include('scripts.tooltips')

@endsection
