@extends('frontend.layouts.app')

@section('template_title')
  Add Studium
@endsection

@section('template_fastload_css')
@endsection

@section('content')

  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">

             Add Studium

            <a href="/studiums" class="btn btn-info btn-xs pull-right">
              <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
              Back <span class="hidden-xs">to</span><span class="hidden-xs"> Studiums</span>
            </a>

          </div>
          <div class="panel-body">

            <form id="regiration_form" novalidate method="POST" action="/studium" enctype="multipart/form-data">

              {!! csrf_field() !!}

            

              <div class="form-group has-feedback row {{ $errors->has('institut') ? ' has-error ' : '' }}">
                {!! Form::label('institut', trans('studiums.nameLabel') , array('class' => 'col-md-3 control-label')); !!}
                <div class="col-md-9">
                    <div class="input-group">
                      {!! Form::text('institut', old('institut'), array('id' => 'institut', 'class' => 'form-control', 'placeholder' => trans('studiums.namePlaceholder'))) !!}
                      <label class="input-group-addon" for="institut"><i class="fa fa-fw fa-pencil }}" aria-hidden="true"></i></label>
                    </div>
                @if ($errors->has('institut'))
                  <span class="help-block">
                    <strong>{{ $errors->first('institut') }}</strong>
                  </span>
                @endif
                </div>
              </div>


             <div class="form-group has-feedback row {{ $errors->has('domain') ? ' has-error ' : '' }}">
                {!! Form::label('domain', trans('studiums.domain'), array('class' => 'col-md-3 control-label')); !!}
                <div class="col-md-9">
                  <div class="input-group">
                    <select class="form-control" name="domain" id="domain">
                      <option value="">{{ trans('studiums.domain') }}</option>
                      @if ($domains->count())
                        @foreach($domains as $domain)
                          <option value="{{ $domain->id }}">{{ $domain->domain }}</option>
                        @endforeach
                      @endif
                    </select>
                    <label class="input-group-addon" for="name"><i class="fa fa-fw {{ trans('forms.create_user_icon_role') }}" aria-hidden="true"></i></label>
                  </div>
                  @if ($errors->has('domain'))
                    <span class="help-block">
                        <strong>{{ $errors->first('domain') }}</strong>
                    </span>
                  @endif
                </div>
              </div>


   



              <div class="form-group has-feedback row {{ $errors->has('degree') ? ' has-error ' : '' }}">
                {!! Form::label('degree', trans('studiums.degree') , array('class' => 'col-md-3 control-label')); !!}
                <div class="col-md-9">
                    <div class="input-group">
                      {!! Form::text('degree', old('degree'), array('id' => 'degree', 'class' => 'form-control', 'placeholder' => trans('studiums.namePlaceholder'))) !!}
                      <label class="input-group-addon" for="degree"><i class="fa fa-fw fa-pencil }}" aria-hidden="true"></i></label>
                    </div>
                @if ($errors->has('degree'))
                  <span class="help-block">
                    <strong>{{ $errors->first('degree') }}</strong>
                  </span>
                @endif
                </div>
              </div>

                


                <div class="form-group has-feedback row {{ $errors->has('start') ? ' has-error ' : '' }}">
                {!! Form::label('start', trans('studiums.start') , array('class' => 'col-md-3 control-label')); !!}
                <div class="col-md-4">
                    <div class="input-group">
                      {!! Form::text('start', old('start'), array('id' => 'start', 'class' => 'form-control', 'placeholder' => trans('studiums.namePlaceholder'))) !!}
                      <label class="input-group-addon" for="start"><i class="fa fa-fw fa-pencil }}" aria-hidden="true"></i></label>
                    </div>
                @if ($errors->has('start'))
                  <span class="help-block">
                    <strong>{{ $errors->first('start') }}</strong>
                  </span>
                @endif
                </div>
              </div>



               <div class="form-group has-feedback row {{ $errors->has('end') ? ' has-error ' : '' }}">
                {!! Form::label('end', trans('studiums.end') , array('class' => 'col-md-3 control-label')); !!}
                <div class="col-md-4">
                    <div class="input-group">
                      {!! Form::text('end', old('end'), array('id' => 'end', 'class' => 'form-control', 'placeholder' => trans('studiums.namePlaceholder'))) !!}
                      <label class="input-group-addon" for="end"><i class="fa fa-fw fa-pencil }}" aria-hidden="true"></i></label>
                    </div>
                @if ($errors->has('end'))
                  <span class="help-block">
                    <strong>{{ $errors->first('end') }}</strong>
                  </span>
                @endif
                </div>
              </div>


              {!! Form::button('<i class="fa fa-plus" aria-hidden="true"></i>&nbsp;' . trans('studiums.btnAddTheme'), array('class' => 'btn btn-success btn-flat margin-bottom-1 pull-right','type' => 'submit', )) !!}

            </form>

          </div>
        </div>
      </div>
    </div>
  </div>

@endsection

@section('footer_scripts')

  @include('scripts.toggleStatus')

@endsection