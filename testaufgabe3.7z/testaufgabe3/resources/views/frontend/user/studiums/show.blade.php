@extends('frontend.layouts.app')

@section('template_title')
  	{{ trans('themes.showHeadTitle') . ' ' . $studium->title }}
@endsection

@section('template_fastload_css')

	.list-group-responsive span:not(.label) {
		display: block;
		overflow-y: auto;
	}
	.list-group-responsive span.label {
		margin-left: 7.25em;
	}

	.theme-details-list strong {
		width: 5.5em;
		display: inline-block;
		position: absolute;
	}

	.theme-details-list span {
	  	margin-left: 5.5em;
	}

@endsection



@section('content')

<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">
					{{ trans('studiums.showTitle') }}
					<a href="/studiums/" class="btn btn-primary btn-xs pull-right">
					  <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
					  {{ trans('studiums.showBackBtn') }}
					</a>
				</div>
				<div class="panel-body">
					<div class="well well-sm">
					    <h1 class="text-center">
					        {{ $studium->institut }}
					    </h1>


						<ul class="list-group list-group-responsive theme-details-list margin-bottom-3">

						

							<li class="list-group-item"><strong>Id   :  </strong> <span>{{ $studium->id }}</span></li>

                            @if($studium->domain != null)
								<li class="list-group-item"><strong>Domain   :  </strong> <span>{{ $studium->domain->domain }}</span></li>
							@endif
							@if($studium->degree != null)
								<li class="list-group-item"><strong>Degree   :  </strong> <span>{{ $studium->degree }}</span></li>
							@endif
							@if($studium->start != null)
								<li class="list-group-item"><strong>Start   :  </strong> <span>{{ $studium->start }}</span></li>
							@endif
							@if($studium->end != null)
								<li class="list-group-item"><strong>End   :  </strong> <span>{{ $studium->end }}</span></li>
							@endif
						

							<li class="list-group-item"><strong>{{ trans('studiums.showAdded') }}</strong> <span>{{ $studium->created_at }}</span></li>
							<li class="list-group-item"><strong>{{ trans('studiums.showUpdated') }}</strong> <span>{{ $studium->updated_at }}</span></li>
						</ul>

					
					</div>
				</div>
				<div class="panel-footer">
					<div class="row">
						<div class="col-xs-6">
							 {!! link_to_route('frontend.user.studium.edit', trans('studiums.showUpdated'), [$studium->id], ['class' => 'btn btn-warning btn-block btn-flat']) !!}
							</a>
						</div>
						{!! Form::open(array('url' => 'frontend.user.studium.destroy' . $studium->id, 'class' => 'col-xs-6')) !!}
							{!! Form::hidden('_method', 'DELETE') !!}
							{!! Form::button('<i class="fa fa-trash-o fa-fw" aria-hidden="true"></i> Delete<span class="hidden-xs hidden-sm"> this</span><span class="hidden-xs"> Studium</span>', array('class' => 'btn btn-danger btn-block btn-flat','type' => 'button', 'data-toggle' => 'modal', 'data-target' => '#confirmDelete', 'data-title' => trans('studiums.confirmDeleteHdr'), 'data-message' => trans('themes.confirmDelete'))) !!}
						{!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@include('modals.modal-delete')

@endsection

@section('footer_scripts')

	@include('scripts.delete-modal-script')
	@include('scripts.tooltips')

@endsection