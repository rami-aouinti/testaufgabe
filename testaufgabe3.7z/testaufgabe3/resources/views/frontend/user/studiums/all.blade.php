@extends('frontend.layouts.app')
@section('page_heading','Dashboard')
@section('content')

            <!-- /.row -->
            <div class="col-sm-12">
            <div class="row">
                <div class="col-lg-2 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Studium</div>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('frontend.user.studiums') }}">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Projects</div>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('frontend.user.studiums') }}">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Experience</div>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('frontend.user.studiums') }}">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Skills</div>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('frontend.user.studiums') }}">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>


            <div class="col-lg-2 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Hobbies</div>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('frontend.user.studiums') }}">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>





          <div class="col-lg-2 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Languages</div>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('frontend.user.studiums') }}">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>














            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                
                @section ('pane2_panel_title', 'Me')
                @section ('pane2_panel_body')
                    
                    <!-- /.panel -->
                    
                        
              
                    <ul class="timeline">
                        <li>
                            <div class="timeline-badge"><i class="fa fa-check"></i>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Studium</h4>
                                    
                                </div>
                                <div class="timeline-body">


                             @foreach($studiums as $studium)

                                        @if($studium->user_id == Auth::User()->id)
                                    <p>
                                     Institut : <strong> {{ $studium->institut}}</strong>    </br> </br> 
                                     Domain : <strong> {{ $studium->domain->domain}}</strong>    </br> </br> 
                                     Degree : <strong> {{ $studium->degree}}</strong>    </br> </br> 
                                     Start : <strong> {{ $studium->start}}</strong>    </br> </br> 
                                     End : <strong> {{ $studium->end}}</strong>    </br> </br> 
                                    
                                     </br> </br> 
                                    </p>
                                     @endif 
                              @endforeach
                                
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-badge warning"><i class="fa fa-credit-card"></i>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Skills</h4>
                                </div>
                                <div class="timeline-body">
                                   @foreach($studiums as $studium)
                                    @if($studium->user_id==Auth::User()->id)
                                    <p>
                                     Institut : <strong> {{$studium->institut}}</strong>    </br> </br> 
                                     Domain : <strong> {{$studium->domain->domain}}</strong>    </br> </br> 
                                     Degree : <strong> {{$studium->degree}}</strong>    </br> </br> 
                                     Start : <strong> {{$studium->start}}</strong>    </br> </br> 
                                     End : <strong> {{$studium->end}}</strong>    </br> </br> 
                                    
                                     </br> </br> 
                                    </p>
                                     @endif 
                                 @endforeach    </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-badge danger"><i class="fa fa-bomb"></i>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Experiences</h4>
                                </div>
                                <div class="timeline-body">
                               @foreach($studiums as $studium)
                                    @if($studium->user_id==Auth::User()->id)
                                    <p>
                                     Institut : <strong> {{$studium->institut}}</strong>    </br> </br> 
                                     Domain : <strong> {{$studium->domain->domain}}</strong>    </br> </br> 
                                     Degree : <strong> {{$studium->degree}}</strong>    </br> </br> 
                                     Start : <strong> {{$studium->start}}</strong>    </br> </br> 
                                     End : <strong> {{$studium->end}}</strong>    </br> </br> 
                                    
                                     </br> </br> 
                                    </p>
                                     @endif 
                                 @endforeach


                                 </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Projects</h4>
                                </div>
                                <div class="timeline-body">
                              @foreach($studiums as $studium)
                                    @if($studium->user_id==Auth::User()->id)
                                    <p>
                                     Institut : <strong> {{$studium->institut}}</strong>    </br> </br> 
                                     Domain : <strong> {{$studium->domain->domain}}</strong>    </br> </br> 
                                     Degree : <strong> {{$studium->degree}}</strong>    </br> </br> 
                                     Start : <strong> {{$studium->start}}</strong>    </br> </br> 
                                     End : <strong> {{$studium->end}}</strong>    </br> </br> 
                                    
                                     </br> </br> 
                                    </p>
                                     @endif 
                                 @endforeach


                                     </div>
                            </div>
                        </li>


                            <li>
                            <div class="timeline-badge"><i class="fa fa-check"></i>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Languages</h4>
                                </div>
                                <div class="timeline-body">
                                @foreach($studiums as $studium)
                                    @if($studium->user_id==Auth::User()->id)
                                    <p>
                                     Institut : <strong> {{$studium->institut}}</strong>    </br> </br> 
                                     Domain : <strong> {{$studium->domain->domain}}</strong>    </br> </br> 
                                     Degree : <strong> {{$studium->degree}}</strong>    </br> </br> 
                                     Start : <strong> {{$studium->start}}</strong>    </br> </br> 
                                     End : <strong> {{$studium->end}}</strong>    </br> </br> 
                                    
                                     </br> </br> 
                                    </p>
                                     @endif 
                                 @endforeach



                                       </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                        <div class="timeline-badge warning"><i class="fa fa-credit-card"></i>
                        </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Hobbies</h4>
                                </div>
                                <div class="timeline-body">
                               
                                @foreach($studiums as $studium)
                                    @if($studium->user_id==Auth::User()->id)
                                    <p>
                                     Institut : <strong> {{$studium->institut}}</strong>    </br> </br> 
                                     Domain : <strong> {{$studium->domain->domain}}</strong>    </br> </br> 
                                     Degree : <strong> {{$studium->degree}}</strong>    </br> </br> 
                                     Start : <strong> {{$studium->start}}</strong>    </br> </br> 
                                     End : <strong> {{$studium->end}}</strong>    </br> </br> 
                                    
                                     </br> </br> 
                                    </p>
                                     @endif 
                                 @endforeach


                                    </div>
                            </div>
                        </li>
                        
                        
                    </ul>
                        
                        <!-- /.panel-body -->
                   
                    <!-- /.panel -->
                @endsection
                @include('widgets.panel', array('header'=>true, 'as'=>'pane2'))
                </div>


                @if($logged_in_user)
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                      <ul class="media-list">
                                <li class="media">
                                    <div class="media-left">
                                        <img class="media-object profile-picture" src="{{ $logged_in_user->picture }}" alt="Profile picture">
                                    </div><!--media-left-->

                                    <div class="media-body">
                                        <h4 class="media-heading">
                                            {{ $logged_in_user->name }}<br/>
                                            <small>
                                                {{ $logged_in_user->email }}<br/>
                                                {{ trans('strings.frontend.general.joined') }} {{ $logged_in_user->created_at->format('F jS, Y') }}
                                            </small>
                                        </h4>

                                        {{ link_to_route('frontend.user.account', trans('navs.frontend.user.account'), [], ['class' => 'btn btn-info btn-xs']) }}

                                        @permission('view-backend')
                                            {{ link_to_route('admin.dashboard', trans('navs.frontend.user.administration'), [], ['class' => 'btn btn-danger btn-xs']) }}
                                        @endauth
                                    </div><!--media-body-->
                                </li><!--media-->
                            </ul><!--media-list-->

                   </div>
              @endif
                <!-- /.col-lg-4 -->
            
@stop
