<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Themes Management Language Lines
    |--------------------------------------------------------------------------
    |
    */

    // Messages
    'createSuccess'     => 'Skill created! ',
    'updateSuccess'     => 'Skill updated! ',
    'deleteSuccess'     => 'Skill deleted! ',
    'deleteSelfError'   => 'You cannot delete the default skill. ',

    // Shared
    'statusLabel'       => 'Skill Status',
    'statusEnabled'     => 'Enabled',
    'statusDisabled'    => 'Disabled',

    'nameLabel'    	 	=> 'Skill Name *',
    'namePlaceholder'   => 'Enter Skill Name',

    'linkLabel'    	 	=> 'Skill CSS Link *',
    'linkPlaceholder'   => 'Enter CSS Link',

    'notesLabel'    	=> 'Skill Notes',
    'notesPlaceholder'  => 'Enter Skill Notes',

    'themes'			=> 'Skills',

    // Add Theme
    'btnAddTheme'    	=> 'Add Skill',

	// Edit Theme
   	'editTitle'    	 	=> 'Editing Skill:',
   	'editSave'    	 	=> 'Save Theme Changes',
Skill
   	// Show Theme
   	'showHeadTitle'		=> 'Skill',
   	'showTitle'    	 	=> 'Skill Information',
   	'showBackBtn'  	 	=> 'Back to Skills',
   	'showUsers' 	    => 'Skill Users',
   	'showStatus'   	 	=> 'Status',
   	'showLink'    	 	=> 'CSS Link',
   	'showNotes'    	 	=> 'Notes',
   	'showAdded'    	 	=> 'Added',
   	'showUpdated'    	=> 'Updated',
   	'confirmDeleteHdr'  => 'Delete Skill',
   	'confirmDelete'    	=> 'Are you sure you want to delete this skill?',

   	// Show Themes
   	'themesTitle'		=> 'Showing All',
   	'themesStatus'		=> 'Status',
   	'themesUsers'		=> 'Users',
   	'themesName'		=> 'Name',
   	'themesLink'		=> 'CSS Link',
   	'themesActions'		=> 'Actions',
   	'themesBtnShow'		=> 'Show Skill',
   	'themesBtnEdit'		=> 'Edit Skill',
   	'themesBtnDelete'	=> '',
   	'themesBtnEdits'	=> '',

];