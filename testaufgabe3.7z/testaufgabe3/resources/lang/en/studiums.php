<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Themes Management Language Lines
    |--------------------------------------------------------------------------
    |
    */

    // Messages
    'createSuccess'     => 'Study created! ',
    'updateSuccess'     => 'Study updated! ',
    'deleteSuccess'     => 'Study deleted! ',
    'deleteSelfError'   => 'You cannot delete the default study. ',

    // Shared
    'statusLabel'       => 'Study Status',
    'statusEnabled'     => 'Enabled',
    'statusDisabled'    => 'Disabled',

    'nameLabel'    	 	=> 'Institut *',
    'namePlaceholder'   => 'Enter Study Name',

    'linkLabel'    	 	=> 'Study CSS Link *',
    'linkPlaceholder'   => 'Enter CSS Link',

    'notesLabel'    	=> 'Study Notes',
    'notesPlaceholder'  => 'Enter Study Notes',

    'themes'			=> 'studiums',

    'domain'      => 'Domain  *',
    'degree'      => 'Degree  *',
    'start'      => 'Start  *',
    'end'      => 'End  *',

    // Add Theme
    'btnAddTheme'    	=> 'Add Study',

	// Edit Theme
   	'editTitle'    	 	=> 'Editing Study:',
   	'editSave'    	 	=> 'Save Study Changes',

   	// Show Theme
   	'showHeadTitle'		=> 'Study',
   	'showTitle'    	 	=> 'Study Information',
   	'showBackBtn'  	 	=> 'Back to Studiums',
   	'showUsers' 	    => 'Study Users',
   	'showStatus'   	 	=> 'Status',
   	'showLink'    	 	=> 'CSS Link',
   	'showNotes'    	 	=> 'Notes',
   	'showAdded'    	 	=> 'Added',
   	'showUpdated'    	=> 'Updated',
   	'confirmDeleteHdr'  => 'Delete Study',
   	'confirmDelete'    	=> 'Are you sure you want to delete this study?',

   	// Show Themes
   	'themesTitle'		=> 'Showing All',
   	'themesStatus'		=> 'Status',
   	'themesUsers'		=> 'Users',
   	'themesName'		=> 'Name',
   	'themesLink'		=> 'CSS Link',
   	'themesActions'		=> 'Actions',
   	'themesBtnShow'		=> 'Show Study',
   	'themesBtnEdit'		=> 'Edit Study',
   	'themesBtnDelete'	=> '',
   	'themesBtnEdits'	=> '',

];