<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Themes Management Language Lines
    |--------------------------------------------------------------------------
    |
    */

    // Messages
    'createSuccess'     => 'Praktikum created! ',
    'updateSuccess'     => 'Praktikum updated! ',
    'deleteSuccess'     => 'Praktikum deleted! ',
    'deleteSelfError'   => 'You cannot delete the default praktikum. ',

    // Shared
    'statusLabel'       => 'Praktikum Status',
    'statusEnabled'     => 'Enabled',
    'statusDisabled'    => 'Disabled',

    'nameLabel'    	 	=> 'Praktikum Name *',
    'namePlaceholder'   => 'Enter Praktikum Name',

    'linkLabel'    	 	=> 'Praktikum CSS Link *',
    'linkPlaceholder'   => 'Enter CSS Link',

    'notesLabel'    	=> 'Praktikum Notes',
    'notesPlaceholder'  => 'Enter Praktikum Notes',

    'themes'			=> 'praktikums',

    // Add Theme
    'btnAddTheme'    	=> 'Add Praktikum',

	// Edit Theme
   	'editTitle'    	 	=> 'Editing Praktikum:',
   	'editSave'    	 	=> 'Save Praktikum Changes',

   	// Show Theme
   	'showHeadTitle'		=> 'Praktikum',
   	'showTitle'    	 	=> 'Praktikum Information',
   	'showBackBtn'  	 	=> 'Back to Praktikums',
   	'showUsers' 	    => 'Praktikum Users',
   	'showStatus'   	 	=> 'Status',
   	'showLink'    	 	=> 'CSS Link',
   	'showNotes'    	 	=> 'Notes',
   	'showAdded'    	 	=> 'Added',
   	'showUpdated'    	=> 'Updated',
   	'confirmDeleteHdr'  => 'Delete Praktikum',
   	'confirmDelete'    	=> 'Are you sure you want to delete this praktikum?',

   	// Show Themes
   	'themesTitle'		=> 'Showing All',
   	'themesStatus'		=> 'Status',
   	'themesUsers'		=> 'Users',
   	'themesName'		=> 'Name',
   	'themesLink'		=> 'CSS Link',
   	'themesActions'		=> 'Actions',
   	'themesBtnShow'		=> 'Show Praktikum',
   	'themesBtnEdit'		=> 'Edit Praktikum',
   	'themesBtnDelete'	=> '',
   	'themesBtnEdits'	=> '',

];