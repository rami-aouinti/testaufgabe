<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Themes Management Language Lines
    |--------------------------------------------------------------------------
    |
    */

    // Messages
    'createSuccess'     => 'Project created! ',
    'updateSuccess'     => 'Project updated! ',
    'deleteSuccess'     => 'Project deleted! ',
    'deleteSelfError'   => 'You cannot delete the default project. ',

    // Shared
    'statusLabel'       => 'Project Status',
    'statusEnabled'     => 'Enabled',
    'statusDisabled'    => 'Disabled',

    'nameLabel'    	 	=> 'Project Name *',
    'namePlaceholder'   => 'Enter Project Name',

    'linkLabel'    	 	=> 'Project CSS Link *',
    'linkPlaceholder'   => 'Enter CSS Link',

    'notesLabel'    	=> 'Project Notes',
    'notesPlaceholder'  => 'Enter Project Notes',

    'themes'			=> 'projects',

    // Add Theme
    'btnAddTheme'    	=> 'Add Project',

	// Edit Theme
   	'editTitle'    	 	=> 'Editing Project:',
   	'editSave'    	 	=> 'Save Project Changes',

   	// Show Theme
   	'showHeadTitle'		=> 'Project',
   	'showTitle'    	 	=> 'Project Information',
   	'showBackBtn'  	 	=> 'Back to Projects',
   	'showUsers' 	    => 'Project Users',
   	'showStatus'   	 	=> 'Status',
   	'showLink'    	 	=> 'CSS Link',
   	'showNotes'    	 	=> 'Notes',
   	'showAdded'    	 	=> 'Added',
   	'showUpdated'    	=> 'Updated',
   	'confirmDeleteHdr'  => 'Delete Project',
   	'confirmDelete'    	=> 'Are you sure you want to delete this project?',

   	// Show Themes
   	'themesTitle'		=> 'Showing All',
   	'themesStatus'		=> 'Status',
   	'themesUsers'		=> 'Users',
   	'themesName'		=> 'Name',
   	'themesLink'		=> 'CSS Link',
   	'themesActions'		=> 'Actions',
   	'themesBtnShow'		=> 'Show Project',
   	'themesBtnEdit'		=> 'Edit Project',
   	'themesBtnDelete'	=> '',
   	'themesBtnEdits'	=> '',

];