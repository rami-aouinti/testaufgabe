<?php

namespace App\Helpers\Macros;

use Collective\Html\FormBuilder;
use App\Helpers\Macros\Traits\Dropdowns;

/**
 * Class Macros.
 */
class Macros extends FormBuilder
{
    use Dropdowns;
}
