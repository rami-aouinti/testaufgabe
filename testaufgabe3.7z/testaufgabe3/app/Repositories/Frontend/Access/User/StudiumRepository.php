<?php

namespace App\Repositories\Frontend\Access\User;

use App\Models\Access\User\Profile\Studium;
use File;

use Illuminate\Support\Facades\DB;
use App\Exceptions\GeneralException;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Hash;
use App\Repositories\Backend\Access\Role\RoleRepository;

/**
 * Class StudiumRepository.
 */
class StudiumRepository extends BaseRepository
{
    

    /**
     * Create a new StudiumRepository instance.
     * @param  \App\Models\Access\User\Profile\Studium $studium
     * @return void
     */
    public function __construct(Studium $studium)
    {
        $this->model = $studium;
    }

    /**
     * Create or update a studium.
     *
     * @param  \App\Models\Access\User\Profile\Studium $studium
     * @param  array  $inputs
     * @param  integer  $user_id
     * @return  \App\Models\Access\User\Profile\Studium
     */
    protected function saveStudium($studium, $inputs, $user_id = null)
    {
	
        $studium->institut = $inputs['institut'];
		$studium->domain_id = $inputs['domain'];
        $studium->degree = $inputs['degree'];
        $studium->start = $inputs['start'];
        $studium->end = $inputs['end'];


         if ($user_id)
        {
        $studium->user_id = $user_id;
        }

        $studium->save();

        return $studium;
    }
	
	

	
	
	

    /**
     * Create a query for Studium.
     * @return Illuminate\Database\Eloquent\Builder
     */
    protected function queryActiveWithUserOrderByDate()
    {
        return $this->model
            ->select('id', 'created_at', 'updated_at', 'institut','domain_id','degree','start','end','user_id')
            ->with('user','domain')
            ->latest();
    }
	
	

    /**
     * Get studium collection.
     *
     * @param  int  $n
     * @return Illuminate\Support\Collection
     */
    public function getActiveWithUserOrderByDate($n)
    {
        return $this->queryActiveWithUserOrderByDate()->paginate($n);
    }

	
	


    /**
     * Get search collection.
     *
     * @param  int  $n
     * @param  string  $search
     * @return Illuminate\Support\Collection
     */
    public function search($n, $search)
    {
        return $this->queryActiveWithUserOrderByDate()
            ->where(function ($q) use ($search) {
                $q->where('title', 'like', "%$search%")
                    ->orWhere('content', 'like', "%$search%");
            })->paginate($n);
    }

    /**
     * Get post collection.
     *
     * @param  int     $n
     * @param  int     $user_id
     * @param  string  $orderby
     * @param  string  $direction
     * @return Illuminate\Support\Collection
     */
    public function getPostsWithOrder($n, $user_id = null, $orderby = 'created_at', $direction = 'desc')
    {
        $query = $this->model
            ->select('studiums.id', 'studiums.created_at', 'title','user_id', 'email')
            ->join('users', 'users.id', '=', 'studiums.user_id')
            ->orderBy($orderby, $direction);

        if ($user_id) {
            $query->where('user_id', $user_id);
        }

        return $query->paginate($n);
    }

    



    /**
     * Update a studium.
     * @param  \App\Models\Access\User\Profile\Studium $studium
     * @param  array  $inputs
     * @param  array  $inputs
     * @return void
     */
    public function update($inputs, $studium)
    {
        $studium = $this->saveStudium($studium, $inputs);

  

    }

	
	
	    /**
     * Get car collection.
     *
      * @param  \App\Models\Access\User\Studium $studium
     * @return array
     */
    public function getPostWithTags($studium)
    {
       


        return compact('studium');
    }
	

	
    
    /**
     * Get car collection.
     *
     * @param  int  $id
     * @return array
     */
    public function getByIdWithTags($id)
    {
        return $this->model->findOrFail($id);
    }


    /**
     * Create a studium.
     *
     * @param  array  $inputs
     * @param  int    $user_id
     * @return void
     */
    public function store($inputs, $user_id)
    {
		

		
        $studium = $this->saveStudium(new $this->model, $inputs, $user_id);


     
    }
	

    /**
     * Get studium collection with studium slug.
     *
     * @param  int  $id
     * @return array
     */
    public function getPostBySlug($id)
    {
        $studium = $this->model->with('user')->whereId($id)->firstOrFail();

        

        return compact('studium');
    }
	

    /**
     * Destroy a studium.
     * @param  \App\Models\Access\User\Profile\Studium $studium
     * @return void
     */
    public function destroy($studium)
    {
        $studium->tags()->detach();

        $studium->delete();
    }


}
