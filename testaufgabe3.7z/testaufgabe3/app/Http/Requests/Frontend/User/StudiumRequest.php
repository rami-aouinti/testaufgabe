<?php

namespace App\Http\Requests\Frontend\User;

use App\Http\Requests\Request;

class StudiumRequest extends Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $id = $this->studium ? ',' . $this->studium : '';
        return [
            'institut' => 'bail|required|max:255',
			'domain_id' => 'bail|required|max:255',
            'degree' => 'bail|required|max:255',
            'start' => 'bail|required|max:255',
            'end' => 'bail|required|max:255',
     
			
        ];
    }
}
