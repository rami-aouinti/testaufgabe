<?php


namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Frontend\Access\User\UserRepository;
use App\Repositories\Frontend\Access\User\StudiumRepository;
use App\Http\Requests\Frontend\User\StudiumRequest;
use App\Http\Requests\Frontend\User\SearchRequest;
use File;
use App\Models\Access\User\User;
use App\Models\Access\User\Profile\Studium;
use App\Models\Access\User\Profile\Domain;


/**
 * Class DashboardController.
 */
class DashboardController extends Controller
{

 /**
     * The StudiumRepository instance.
     *
     * @var \App\Repositories\Frontend\Access\User\Profile\StudiumRepository
     */
    protected $studiumRepository;
    
    
      /**
     * The UserRepository instance.
     *
     * @var \App\Repositories\Frontend\Access\User\UserRepository
     */
    protected $userRepository;
    


    /**
     * The pagination number.
     *
     * @var int
     */
    protected $nbrPages;

    /**
     * Create a new StudiumController instance.
     * @param  \App\Repositories\Frontend\Access\User\StudiumRepository $studiumRepository
     * @param  \App\Repositories\Frontend\Access\User\UserRepository $userRepository
     * @return void
    */
    public function __construct(StudiumRepository $studiumRepository,UserRepository $userRepository)
    {
        $this->studiumRepository = $studiumRepository;
         $this->userRepository = $userRepository;
        $this->nbrPages = config('app.nbrPages.front.studiums');
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view('frontend.user.dashboard');
    }

    /**
     * @return \Illuminate\Http\Response
     */
    public function home()
    {

        $studiums = $this->studiumRepository->getActiveWithUserOrderByDate($this->nbrPages);
        return view('home', compact('studiums'));
    }
}
