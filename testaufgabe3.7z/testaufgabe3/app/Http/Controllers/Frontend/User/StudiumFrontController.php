<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Frontend\Access\User\UserRepository;
use App\Repositories\Frontend\Access\User\StudiumRepository;
use App\Http\Requests\Frontend\User\StudiumRequest;
use App\Http\Requests\Frontend\User\SearchRequest;
use File;
use App\Models\Access\User\User;
use App\Models\Access\User\Profile\Studium;
use App\Models\Access\User\Profile\Domain;




class StudiumFrontController extends Controller
{
    /**
     * The StudiumRepository instance.
     *
     * @var \App\Repositories\Frontend\Access\User\Profile\StudiumRepository
     */
    protected $studiumRepository;
	
	
	  /**
     * The UserRepository instance.
     *
     * @var \App\Repositories\Frontend\Access\User\UserRepository
     */
    protected $userRepository;
	


    /**
     * The pagination number.
     *
     * @var int
     */
    protected $nbrPages;

    /**
     * Create a new StudiumController instance.
     * @param  \App\Repositories\Frontend\Access\User\StudiumRepository $studiumRepository
	 * @param  \App\Repositories\Frontend\Access\User\UserRepository $userRepository
     * @return void
    */
    public function __construct(StudiumRepository $studiumRepository,UserRepository $userRepository)
    {
        $this->studiumRepository = $studiumRepository;
	     $this->userRepository = $userRepository;
        $this->nbrPages = config('app.nbrPages.front.studiums');
    }

    /**
     * Display a listing of the studiums.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $studiums = $this->studiumRepository->getActiveWithUserOrderByDate($this->nbrPages);
        return view('frontend.user.studiums.index', compact('studiums'));
     }




       /**
     * Display a listing of the studiums.
     *
     * @return \Illuminate\Http\Response
     */
    public function all()
    {
        $studiums = $this->studiumRepository->getActiveWithUserOrderByDate($this->nbrPages);
        return view('frontend.user.studiums.all', compact('studiums'));
     }

	
    /**
     * Display the specified studium.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Integer $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $user = $request->user();

        return view('frontend.user.studiums.show', array_merge($this->studiumRepository->getPostBySlug($id), compact('user')));
    }



    /**
     * Find search in studium
     *
     * @param  \App\Http\Requests\SearchRequest $request
     * @return \Illuminate\Http\Response
     */
    public function search(SearchRequest $request)
    {
        $search = $request->input('search');
        $studiums = $this->studiumRepository->search($this->nbrPages, $search);
        $links = $studiums->appends(compact('search'))->links();
        $info = trans('front/blog.info-search') . '<strong>' . $search . '</strong>';
        
        return view('frontend.user.studiums.index', compact('studiums', 'links', 'info'));
    }
	
	
	
	
	
	
	
	/**
     * Show the form for creating a new post.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		
		$domains = Domain::all();
		$users = User::all();
        return view('frontend.user.studiums.create', compact('users','domains'));
    }

    /**
     * Store a newly created post in storage.
     *
     * @param  \App\Http\Requests\Frontend\User\StudiumRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(StudiumRequest $request)
  {

        $this->studiumRepository->store($request->all(), $request->user()->id);

        return redirect('studiums');
    }
	


    /**
     * Show the form for editing the specified post.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {




        $domains = Domain::all();
        $studium = $this->studiumRepository->getByIdWithTags($id);

		
        return view('frontend.user.studiums.edit', $this->studiumRepository->getPostWithTags($studium), compact('users','domains'));
    }

    /**
     * Update the specified car in storage.
     *
     * @param  App\Http\Requests\Frontend\User\StudiumRequest $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StudiumRequest $request, $id)
    {
        $studium = $this->studiumRepository->getById($id);

      

        $this->studiumRepository->update($request->all(), $studium);

        return redirect('studiums')->with('ok', trans('back/blog.updated'));
    }

    /**
     * Remove the specified studium from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $studium = $this->studiumRepository->getById($id);

    

        $this->studiumRepository->destroy($studium);

        return redirect('studiums')->with('ok', trans('back/blog.destroyed'));
    }
	
	
	

	
	
	
}
