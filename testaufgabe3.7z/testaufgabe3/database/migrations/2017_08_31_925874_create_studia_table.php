<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudiaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('studia', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('institut', 255);
            $table->string('degree', 255);
            $table->string('start', 255);
            $table->string('end', 255);
            $table->integer('domain_id')->unsigned();
            $table->integer('user_id')->unsigned();
        });

        Schema::table('studia', function (Blueprint $table) {

            

         $table->foreign('domain_id')->references('id')->on('domains')
                        ->onDelete('restrict')
                        ->onUpdate('restrict');   



         $table->foreign('user_id')->references('id')->on('users')
                        ->onDelete('restrict')
                        ->onUpdate('restrict');                               

                      
        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('studia', function (Blueprint $table) {
            $table->dropForeign('studia_user_id_foreign');
            $table->dropForeign('studia_domain_id_foreign');
        });

    
        Schema::drop('studia');
    }
}
